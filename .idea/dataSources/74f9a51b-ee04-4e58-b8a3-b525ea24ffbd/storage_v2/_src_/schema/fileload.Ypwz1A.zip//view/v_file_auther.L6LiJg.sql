CREATE VIEW v_file_auther AS
  SELECT
    `fileload`.`file_rec`.`fileName`  AS `filename`,
    `fileload`.`file_rec`.`fileClass` AS `fileclass`,
    `fileload`.`file_rec`.`auther`    AS `auther`
  FROM `fileload`.`file_rec`;

